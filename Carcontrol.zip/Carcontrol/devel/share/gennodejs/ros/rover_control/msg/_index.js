
"use strict";

let corner = require('./corner.js');
let rover = require('./rover.js');

module.exports = {
  corner: corner,
  rover: rover,
};
